function generateTable() {
  const number = document.getElementById('numberInput').value;
  const outputDiv = document.getElementById('tableOutput');

  if (number === '' || isNaN(number)) {
      outputDiv.innerHTML = "Please enter a valid number!";
      return;
  }

  let table = `<p>Multiplication Table of ${number}:</p>`;
  for (let i = 1; i <= 10; i++) {
      table += `${number} x ${i} = ${number * i}<br>`;
  }

  outputDiv.innerHTML = table;
}
